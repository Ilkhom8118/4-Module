﻿namespace e_CommerceSystem_.Dal.Enums;

public enum StatusPayment
{
    Pending,        // To'lov kutilmoqda
    Completed,      // To'lov muvaffaqiyatli amalga oshirildi
    Failed,         // To'lov amalga oshirilmadi
    Refunded        // To'lov qaytarib berildi
}
