﻿namespace e_CommerceSystem.Repoistory;

public class Class1
{

}
