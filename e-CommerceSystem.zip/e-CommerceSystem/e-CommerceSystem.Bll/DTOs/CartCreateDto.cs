﻿using e_CommerceSystem_.Dal.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace e_CommerceSystem.Bll.DTOs
{
    public class CartCreateDto
    {
        public long UserId { get; set; }
    }
}
