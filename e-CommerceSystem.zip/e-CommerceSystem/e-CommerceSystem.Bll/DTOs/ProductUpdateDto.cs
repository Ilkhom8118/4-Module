﻿namespace e_CommerceSystem.Bll.DTOs
{
    public class ProductUpdateDto
    {
        public long Id { get; set; }
        public decimal Price { get; set; }
        public decimal Stock { get; set; }
    }
}
