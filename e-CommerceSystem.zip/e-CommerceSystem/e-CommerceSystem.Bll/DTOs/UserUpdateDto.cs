﻿using e_CommerceSystem_.Dal.Enums;

namespace e_CommerceSystem.Bll.DTOs;

public class UserUpdateDto
{
    public long Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    
}
